public class Ejercicio5 {
    public static void main(String[] args) {
        /* System.out.println('0');
        System.out.println('1');
        System.out.println('2');
        System.out.println('3');
        System.out.println('4');
         */
        System.out.println(0+1+2+3+4); //NÚMEROS
        System.out.println('0'+'1'+'2'+'3'+'4');
        System.out.println("0\n1\n2\n3\n4");
    }
}
