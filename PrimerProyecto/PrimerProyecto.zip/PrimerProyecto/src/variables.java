public class variables {
    public static void main(String[] args) {
       //declaramos primero las variables: tipo identificador
       int x = 10, y = 20, z = x + y; //con el = las inicializo
        String cadena = "suma";


    }
}
