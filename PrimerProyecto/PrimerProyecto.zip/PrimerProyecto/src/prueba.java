import java.util.Scanner;

public class prueba {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in); //Creo un scanner para leer por teclado
        System.out.println("Hola, como te llamas?"); //esto me lo podria saltar
        String nombre = teclado.nextLine();
    }

}
