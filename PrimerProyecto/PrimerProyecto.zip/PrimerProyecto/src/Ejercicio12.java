import java.util.Scanner;

public class Ejercicio12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe la Java:");
        String palabra1 = sc.nextLine();
        System.out.println("Escribe la Programación:");
        String palabra2 = sc.nextLine();
        System.out.println("Escribe la Idioma:");
        String palabra3 = sc.nextLine();
        System.out.println(palabra3);
        System.out.println(palabra2);
        System.out.println(palabra1);

    }
}
