class Ejercicio17 {
    public static void main(String[] args) {
// Asigna valores a estas cuatro valores
        int one = 1;
        int two = 2;
        int three = 3;
        int four = 4;
        System.out.println(String.format("%d %d %d %d", one, two, three, four));
    }
}