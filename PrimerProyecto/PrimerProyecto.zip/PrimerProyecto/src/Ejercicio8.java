public class Ejercicio8 {
    //Punto de partida del programa
    public static void main(String[] args) {
        System.out.println("¡Compila!"); //Imprime "¡Compila!"
    }
}
