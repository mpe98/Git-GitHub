public class Ejercicio16 {
    public static void main(String[] args) {
        int numeros = 123456;
        System.out.println(numeros);
    }
}
