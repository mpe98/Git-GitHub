public class Ejercicio15 {
    public static void main(String[] args) {
        int a = 3;
        int b = 5;
        int c = 4;
        System.out.println(a + " " + b + " " + c);
    }
}
