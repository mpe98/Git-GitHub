public class Ejercicio3 {
    public static void main(String[] args) {
        System.out.println("primera");
        System.out.println("segunda");
        System.out.println("tercera");
    }
}
// Otra forma de hacerlo: System.out.println("primera\n segunda\n tercera\n");

