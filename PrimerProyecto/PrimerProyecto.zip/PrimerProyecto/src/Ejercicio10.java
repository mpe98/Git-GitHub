public class Ejercicio10 {
    public static void main(String[] args) {
        System.out.print("¡Tres! ");
        System.out.print("¡Dos! ");
        System.out.println("¡Uno!");
        System.out.println("¡Adelante!");
    }
}
