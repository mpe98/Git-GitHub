public class Ejercicio11 {
    public static void main(String[] args) {
        System.out.println("Esta\n Plataforma\n Java\n Es\n Adaptativa");
    }
}
