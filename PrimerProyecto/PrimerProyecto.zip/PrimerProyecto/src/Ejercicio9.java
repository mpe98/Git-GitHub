public class Ejercicio9 {
    public static void main(String[] args) {
        System.out.println("Otra aplicacion más simple de Java");
        //System.out.println("No imprimas esta línea.")
    }
}
